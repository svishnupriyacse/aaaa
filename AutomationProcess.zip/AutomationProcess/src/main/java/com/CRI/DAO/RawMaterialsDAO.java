package com.CRI.DAO;

import com.CRI.model.RawMaterials;

public interface RawMaterialsDAO {
	
	public void save(RawMaterials r);

}
