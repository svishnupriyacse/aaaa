package com.CRI.DAO;



import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.CRI.model.RawMaterials;

public class RawMaterialsImpl implements RawMaterialsDAO {
	
	@Autowired
	private SessionFactory sessionFactory;

	

	public RawMaterialsImpl(SessionFactory sessionFactory) {
		super();
		this.sessionFactory = sessionFactory;
	}



	@Transactional
	public void save(RawMaterials r) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().saveOrUpdate(r);
	}

}
