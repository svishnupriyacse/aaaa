package com.CRI.DAO;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.CRI.model.Supplier;

public class SupplierDAOImpl implements SupplierDAO{

	@Autowired
	private SessionFactory sessionFactory;

	public SupplierDAOImpl(SessionFactory sessionFactory) {
		super();
		this.sessionFactory = sessionFactory;
	}

	@Transactional
	public void save(Supplier s) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().saveOrUpdate(s);
	}

	@Transactional
	public List<Supplier> get() {
		// TODO Auto-generated method stub
		@SuppressWarnings("unchecked")
		List<Supplier> listSupplier = (List<Supplier>)
				sessionFactory.getCurrentSession().createCriteria(Supplier.class)
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
				return listSupplier;
	}

	@Transactional
	public Supplier get(int id) {
		// TODO Auto-generated method stub
		String hql = "from Supplier where supplierId ='" + id + "'";
		org.hibernate.Query query = sessionFactory.getCurrentSession().createQuery(hql);
		@SuppressWarnings("unchecked")
		List<Supplier> listSuppliers = (List<Supplier>) query.list();
		if (listSuppliers != null && !listSuppliers.isEmpty()) {
			return listSuppliers.get(0);
		}
		return null;
		
	}

}
