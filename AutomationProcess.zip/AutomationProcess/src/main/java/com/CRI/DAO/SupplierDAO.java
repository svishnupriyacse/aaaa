package com.CRI.DAO;


import java.util.List;

import com.CRI.model.Supplier;

public interface SupplierDAO {
	
	public void save(Supplier s);
	public List<Supplier> get();
	public Supplier get(int id);


}
