package com.CRI.model;



import java.util.Date;

import javax.annotation.Generated;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.datetime.joda.DateTimeParser;
import org.springframework.stereotype.Component;

@Entity
@Table(name="RawMaterials")
@Component
public class RawMaterials {
	@Id
	@GeneratedValue
	private int Material_id;
	
	
	public Date getRDate() {
		return RDate;
	}

	public void setRDate(Date rDate) {
		RDate = rDate;
	}
	@Generated(value = { "" })
	@Temporal(javax.persistence.TemporalType.DATE)
	private Date RDate = new java.sql.Date(new java.util.Date().getTime());
	
	private int Vendor_serial_no;
	private float Coil_size;
	
	public float getCoil_size() {
		return Coil_size;
	}

	public void setCoil_size(float coil_size) {
		Coil_size = coil_size;
	}
	
	
	
	public float getWeight() {
		return weight;
	}

	public void setWeight(float weight) {
		this.weight = weight;
	}
	
	public int getVendor_serial_no() {
		return Vendor_serial_no;
	}

	public void setVendor_serial_no(int vendor_serial_no) {
		Vendor_serial_no = vendor_serial_no;
	}
	@ManyToOne
	@JoinColumn(name="Supplier_id")
	private Supplier supplier;
	
	public Supplier getSupplier() {
		return supplier;
	}

	public void setSupplier(Supplier supplier) {
		this.supplier = supplier;
	}
	
	private float weight;
	public int getMaterial_id() {
		return Material_id;
	}
	
	public void setMaterial_id(int material_id) {
		Material_id = material_id;
	}
	
	
	
}
