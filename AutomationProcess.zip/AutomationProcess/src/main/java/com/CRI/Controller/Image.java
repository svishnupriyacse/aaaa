package com.CRI.Controller;


import java.io.ByteArrayInputStream;

import java.io.FileInputStream;

import java.io.IOException;
import java.io.InputStream;


import javax.print.Doc;
import javax.print.DocFlavor;
import javax.print.DocPrintJob;
import javax.print.PrintException;
import javax.print.PrintService;
import javax.print.PrintServiceLookup;
import javax.print.SimpleDoc;
import javax.print.attribute.DocAttributeSet;
import javax.print.attribute.HashDocAttributeSet;
import javax.print.attribute.HashPrintRequestAttributeSet;
import javax.print.attribute.PrintRequestAttributeSet;
import javax.print.attribute.standard.Copies;
import javax.print.attribute.standard.PrinterResolution;

import com.CRI.model.RawMaterials;

public class Image {
	public static void createImage(RawMaterials r) throws PrintException, IOException{
		String text = "Supplier Name:"+r.getSupplier_name()+"\r\nPlant Location:"+r.getPlant_location()+"\r\nWeight:"+r.getWeight()+"kgs\r\n";
		String defaultPrinter =
			      PrintServiceLookup.lookupDefaultPrintService().getName();
			    System.out.println("Default printer: " + defaultPrinter);
			    PrintService service = PrintServiceLookup.lookupDefaultPrintService();

			    // prints the famous hello world! plus a form feed
			    InputStream is = new ByteArrayInputStream(text.getBytes("UTF8"));
			   
			   

			    PrintRequestAttributeSet  pras = new HashPrintRequestAttributeSet();
			    pras.add(new Copies(1));

			    DocFlavor flavor = DocFlavor.INPUT_STREAM.AUTOSENSE;
			    Doc doc = new SimpleDoc(is, flavor, null);
			    DocPrintJob job = service.createPrintJob();
			    DocAttributeSet das = new HashDocAttributeSet();  
		          das.add(new PrinterResolution(203,203,PrinterResolution.DPI));  
		          //das.add(new PrintQuality(3));  
		             
			    PrintJobWatcher pjw = new PrintJobWatcher(job);
			    job.print(doc, pras);
			    
			    pjw.waitForDone();
			    is.close();
	}
	public static void printbarcode(String Filename) throws PrintException, IOException{
		
		String defaultPrinter =
			      PrintServiceLookup.lookupDefaultPrintService().getName();
			    System.out.println("Default printer: " + defaultPrinter);
			    PrintService service = PrintServiceLookup.lookupDefaultPrintService();

			    // prints the famous hello world! plus a form feed
			   
			    FileInputStream fin = new FileInputStream(Filename);
			   

			    PrintRequestAttributeSet  pras = new HashPrintRequestAttributeSet();
			    pras.add(new Copies(1));
			    DocAttributeSet das = new HashDocAttributeSet(); 
			    Doc image = new SimpleDoc(fin, DocFlavor.INPUT_STREAM.PNG, das); 
			    DocPrintJob job = service.createPrintJob();
			    
		          das.add(new PrinterResolution(203,203,PrinterResolution.DPI));  
		          //das.add(new PrintQuality(3));  
		          
		             
			    PrintJobWatcher pjw = new PrintJobWatcher(job);
			   
			    job.print(image, pras);
			    pjw.waitForDone();
			    fin.close();
		
		
	}
}
