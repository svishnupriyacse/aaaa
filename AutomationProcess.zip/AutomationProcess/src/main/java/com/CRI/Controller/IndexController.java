package com.CRI.Controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.CRI.DAO.SupplierDAO;
import com.CRI.model.RawMaterials;
import com.CRI.model.Supplier;



@Controller
public class IndexController {

	
	@Autowired
	SupplierDAO sup;
	
	@RequestMapping("/")
	public String getindex(Model model){
		RawMaterials r = new RawMaterials();
		Supplier s = new Supplier();
		r.setSupplier(s);
		model.addAttribute("raw", r);
		return "index";
	}
	
	@RequestMapping(value="edit/{id}")
	public ModelAndView editproduct(@PathVariable("id") int id, Model model){
		System.out.println(id);
	Supplier supplier = sup.get(id);
		//model.
		model.addAttribute("product", supplier);
		return new ModelAndView("index");
	}

}
