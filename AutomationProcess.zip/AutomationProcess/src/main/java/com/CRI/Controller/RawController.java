package com.CRI.Controller;

import java.sql.SQLIntegrityConstraintViolationException;

import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.CRI.DAO.RawMaterialsDAO;
import com.CRI.model.RawMaterials;

@Controller
public class RawController {
	
	@Autowired
	RawMaterialsDAO raw;
	
	@RequestMapping(value="/NewRaw", method=RequestMethod.POST)
	public String AddRaw(@ModelAttribute ("RawMaterials") RawMaterials rawMaterials,BindingResult result,Model model) throws SQLIntegrityConstraintViolationException{
		System.out.println(rawMaterials.getRDate());
		raw.save(rawMaterials);
		//String Filename = BarCode.generatebarcode(rawMaterials);
		//Image.createImage(rawMaterials);
		///Image.printbarcode(Filename);
		return "index";
	}
	
	

}
