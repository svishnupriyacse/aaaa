package com.CRI.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.CRI.DAO.SupplierDAO;
import com.CRI.model.Supplier;

@Controller
public class SupplierController {
	
	@Autowired
	SupplierDAO sup;
	
	@RequestMapping("/NewSupplier")
	public String AddSupplier(){
		return "AddSupplier";
		
		
	}
	@RequestMapping("/addSupplier")
	public String Addsupp(@ModelAttribute("Supplier") Supplier supplier){
		System.out.println(supplier.getSupplierName());
		sup.save(supplier);
		return "AddSupplier";	
	}
	
	@RequestMapping("/ViewSupplier")
	public ModelAndView viewSupplier(){
		List<Supplier> suppliers = sup.get();
		
		ModelAndView mv = new ModelAndView("ViewSupplier");
		mv.addObject("list", suppliers);
		return mv;
		
	}
	@ExceptionHandler({Exception.class})
	public ModelAndView showerrorpage(){
		
		ModelAndView mv = new ModelAndView("404");
		mv.addObject("msg","hi helooa");
		return mv;
		
	}
	
	


}
